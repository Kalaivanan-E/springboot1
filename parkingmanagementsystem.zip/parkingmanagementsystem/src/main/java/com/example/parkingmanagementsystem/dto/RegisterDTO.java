package com.example.parkingmanagementsystem.dto;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class RegisterDTO {

    private String userName;
    private String email;
    private String password;
    private String confirmPassword;
    private Long phoneNumber;
}
