package com.example.parkingmanagementsystem.service;

public interface RegisterService {

}
