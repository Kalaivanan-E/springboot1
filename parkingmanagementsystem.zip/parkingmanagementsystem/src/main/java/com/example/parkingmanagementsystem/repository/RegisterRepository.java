package com.example.parkingmanagementsystem.repository;

import com.example.parkingmanagementsystem.entity.RegisterEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegisterRepository extends JpaRepository<RegisterEntity, Long> {

}
